


console.log('[System] Starting Discord Bot...');
require('./bot/index.js');

console.log('[System] Starting Web Dashboard...');
require('./dashboard/server.js');

